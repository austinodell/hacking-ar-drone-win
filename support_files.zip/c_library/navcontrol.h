#ifndef NAVCONTROL_H
#define NAVCONTROL_H

int navSetup();
int navClose();
int navGetSample();
float navGetGX();
float navGetGY();
float navGetGZ();
float navGetAX();
float navGetAY();
float navGetAZ();
float navGetMX();
float navGetMY();
float navGetMZ();
float navGetHeight();

#endif