#ifndef VBATCONTROL_H
#define VBATCONTROL_H

int getVoltage();

#endif